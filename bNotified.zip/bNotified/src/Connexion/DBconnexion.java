/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Connexion;


import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author BETHEL
 */
public class DBconnexion {
    
    private static Connection con;

    public static Connection getCon() {
        if (con == null){
            try { 
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                String url = "jdbc:mysql://localhost:3306/dbstudent";
                String login = "root";
                String password = "";
                 con = (Connection) java.sql.DriverManager.getConnection(url,login,password);
                
            } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException ex) {
                Logger.getLogger(DBconnexion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return con;
    }
    
    
}
