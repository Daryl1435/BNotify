package Gui;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Formatter;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import org.smslib.helper.CommPortIdentifier;
import org.smslib.helper.SerialPort;


/**
 *
 * @author TATA
 */
public class ActiveCommPortDetector {    

    private static double totalProgress = 0;    
 private static final String _NO_DEVICE_FOUND = "  no device found";
  private String simNum = null;
    private String comm = null ;
@FXML
    private static Label status;
	private final static Formatter _formatter = new Formatter(System.out);
        private static String activeCommPorts[] = new String[90];

	static CommPortIdentifier portId;

	static Enumeration<CommPortIdentifier> portList;

	static int bauds[] = { 9600, 14400, 19200, 28800, 33600, 38400, 56000, 57600, 115200 };
        
	
	private static Enumeration<CommPortIdentifier> getCleanPortIdentifiers()
	{
		return CommPortIdentifier.getPortIdentifiers();
	}

	public static void detectDevice() throws IOException, InterruptedException
	{
		System.out.println("\nSearching for devices...");
		portList = getCleanPortIdentifiers();              
        String simMobileNum = null;
        String gatewayInternational = null;
        String gatewaySoftVer = null;
        String gatewayIMEI = null;
        String gatewayMan = null;
        
        double commStep = 0;
       /* int tmp = ActiveCommPortDetector.getNumOfCommPOrts();
        if( tmp != 0){
            commStep = 100 / tmp;
        } */
            double incStep = commStep / 9;
            
        
		while (portList.hasMoreElements())
		{
			portId = portList.nextElement();
                        //System.out.println(portId);
			if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL)
			{
				_formatter.format("%nFound port: %-5s%n", portId.getName());
				for (int i = 0; i < bauds.length; i++)
				{
					SerialPort serialPort = null;
					_formatter.format("       Trying at %6d...", bauds[i]);
                                        
                                        //StatusBar.onProcess(status, "       Trying at %6d..." + bauds[i]);
                                       
					try
					{
						InputStream inStream;
						OutputStream outStream;
						int c;
						String response; //response from the AT command
						serialPort = portId.open("Abstraction", 1971);
						serialPort.setFlowControlMode(SerialPort.FLOWCONTROL_RTSCTS_IN);
						serialPort.setSerialPortParams(bauds[i], SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
						inStream = serialPort.getInputStream();
						outStream = serialPort.getOutputStream();
						serialPort.enableReceiveTimeout(1000);
						c = inStream.read();
                                            //System.out.println(c);
						while (c != -1)
							c = inStream.read(); // end of loop?
						outStream.write('A');
						outStream.write('T');
						outStream.write('\r');
						Thread.sleep(1000);
						response = "";
						StringBuilder sb = new StringBuilder();
						c = inStream.read();
                                            //System.out.println( c + (char) c); //peeking
						while (c != -1)
						{
							sb.append((char) c);
							c = inStream.read();
						}
						response = sb.toString();   //----------------convert sb to string and place results in response
						if (response.indexOf("OK") >= 0)
						{
                                                    ActiveCommPortDetector.push(portId.getName() + "-" + bauds[i]); //filling the array
                                                    totalProgress = incStep;
                                                    
							try
							{
								//communication with the communication port
                                                                System.out.print("  Getting Info...");
								
							}
							catch (Exception e)
							{
								System.out.println(_NO_DEVICE_FOUND);
							}
						}
						else
						{
							System.out.println(_NO_DEVICE_FOUND);
						}
					}
					catch (Exception e)
					{
						System.out.print(_NO_DEVICE_FOUND);
						Throwable cause = e;
						while (cause.getCause() != null)
						{
							cause = cause.getCause();
						}
						System.out.println(" (" + cause.getMessage() + ")");  //display the possible problem on screen
					}
					finally
					{
						if (serialPort != null)
						{
							serialPort.close();
						}
					}

				}
			}
		}

        System.out.println(CommPortIdentifier.PORT_SERIAL);        
        
        
                System.out.println("DEVICE INFORMATION");
                System.out.println("------------------------------");
                System.out.println("\t>>>the SIM CARD TELEPHONE NUMBER is : " + simMobileNum);
                System.out.println("\t>>>the International Mobile Subscriber Identity is : " + gatewayInternational);
                System.out.println("\t>>>the software version is : " + gatewaySoftVer);
                 System.out.println("\t>>>the Modem's IMEI is : " + gatewayIMEI);
                 System.out.println("\t>>>the modem manufacturer is : " + gatewayMan);
		System.out.println("\nTest complete.");
                
                int counter = 0;
                for(int i = 0; i < activeCommPorts.length; i++){
                    if(activeCommPorts[i] != null){
                        System.out.println(activeCommPorts[i]);
                    }
                    if(activeCommPorts[i] == null){
                        counter += 1;
                    }                    
                    
                }
                
                if(counter == activeCommPorts.length){
                    System.out.println("NO DEVICE WAS FOUND");
                }
                else{
                     System.out.println(ActiveCommPortDetector.getActiveBaudRate());
                    System.out.println(ActiveCommPortDetector.getActiveCommPort());
                }
                
                System.out.println("------------------------------");
               
	}
   
        
        public String getSimNumber(){
            return this.simNum;
        }
        
        public static String getActiveCommPort(){
            String wor;
            wor = ActiveCommPortDetector.activeCommPorts[1];
            if(wor != null){
                int sep = wor.indexOf('-');
                String com;
                com = wor.subSequence(0, sep).toString();
                return com; 
            }
            return null;
                       
        }
        
        public static int getActiveBaudRate(){                                           
            String wor;
            wor = ActiveCommPortDetector.activeCommPorts[1];
            if(wor != null){
                int sep = wor.indexOf('-');
                String com;
                com = wor.subSequence(sep + 1, wor.length()).toString();
                int baud = Integer.parseInt(com);                
                return baud;
            }
            return 0;
                                                           
        }
        
        public static boolean pingPort(int baud) throws IOException, InterruptedException{
            InputStream inStream;
						OutputStream outStream;
						int c;
						String response; //response from the AT command
     SerialPort serialPort = portId.open("Abstraction", 1971);
						serialPort.setFlowControlMode(SerialPort.FLOWCONTROL_RTSCTS_IN);
						serialPort.setSerialPortParams(baud, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
						inStream = serialPort.getInputStream();
						outStream = serialPort.getOutputStream();
						serialPort.enableReceiveTimeout(1000);
						c = inStream.read();
                                            //System.out.println(c);
						while (c != -1)
							c = inStream.read(); // end of loop?
						outStream.write('A');
						outStream.write('T');
						outStream.write('\r');
						Thread.sleep(1000);
						response = "";
						StringBuilder sb = new StringBuilder();
						c = inStream.read();
                                            //System.out.println( c + (char) c); //peeking
						while (c != -1)
						{
							sb.append((char) c);
							c = inStream.read();
						}
						response = sb.toString();   //----------------convert sb to string and place results in response
                                                if (response.indexOf("OK") >= 0){
                                                    return true;
                                                }
                                                return false;
        }
        
        public static int getNumOfCommPOrts(){
            int num = 0;
            portList = getCleanPortIdentifiers();
            while(portList.hasMoreElements()){
                portId = portList.nextElement();
                        //System.out.println(portId);
			if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL)
			{
                            System.out.println(num);
                             num += 1;
                        }
            }
            return num;
        }
        
        public static double getProgress(){            
            return ActiveCommPortDetector.totalProgress;
        }
        
        
        public static void push(String val){
            for(int i = 0; i < ActiveCommPortDetector.activeCommPorts.length; i++){
                if(activeCommPorts[i] == null){
                    activeCommPorts[i] = val;
                    break;
                }
                else{
                    continue;
                }
            }
        }                       
        
         
}
    
