// // ReadMessages.java - Sample application.
////
//// This application shows you the basic procedure needed for reading
//// SMS messages from your GSM modem, in synchronous mode.
////
//// Operation description:
//// The application setup the necessary objects and connects to the phone.
//// As a first step, it reads all messages found in the phone.
//// Then, it goes to sleep, allowing the asynchronous callback handlers to
//// be called. Furthermore, for callback demonstration purposes, it responds
//// to each received message with a "Got It!" reply.
////
//// Tasks:
//// 1) Setup Service object.
//// 2) Setup one or more Gateway objects.
//// 3) Attach Gateway objects to Service object.
//// 4) Setup callback notifications.
//// 5) Run
//
//package examples.modem;
//
//import Connexion.DBconnexion;
//import Gestion.GestionEdutiant;
//import Gui.SmsInterface;
//import com.mysql.jdbc.PreparedStatement;
//import java.io.IOException;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//import javax.crypto.spec.SecretKeySpec;
//import org.smslib.AGateway;
//import org.smslib.AGateway.GatewayStatuses;
//import org.smslib.AGateway.Protocols;
//import org.smslib.ICallNotification;
//import org.smslib.IGatewayStatusNotification;
//import org.smslib.IInboundMessageNotification;
//import org.smslib.IOrphanedMessageNotification;
//import org.smslib.InboundMessage;
//import org.smslib.InboundMessage.MessageClasses;
//import org.smslib.Library;
//import org.smslib.Message.MessageTypes;
//import org.smslib.Service;
//import org.smslib.crypto.AESKey;
//import org.smslib.modem.SerialModemGateway;
//import java.util.Scanner;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//import javax.swing.JTextArea;
//import org.smslib.GatewayException;
//import org.smslib.OutboundMessage;
//import org.smslib.TimeoutException;
//import java.util.regex.*;
//
//public class ReadMessages
//{
//   
//       
//    
//	public void doIt() throws Exception
//	{
//		// Define a list which will hold the read messages.
//		List<InboundMessage> msgList;
//		// Create the notification callback method for inbound & status report
//		// messages.
//		InboundNotification inboundNotification = new InboundNotification();
//		// Create the notification callback method for inbound voice calls.
//		CallNotification callNotification = new CallNotification();
//		//Create the notification callback method for gateway statuses.
//		GatewayStatusNotification statusNotification = new GatewayStatusNotification();
//		OrphanedMessageNotification orphanedMessageNotification = new OrphanedMessageNotification();
//        
//        
//                
//                Scanner read = new Scanner(System.in);
//                 Scanner input = new Scanner(System.in);
//                
//		try
//		{
//			System.out.println("Example: Read messages from a serial gsm modem.");
//			System.out.println(Library.getLibraryDescription());
//			System.out.println("Version: " + Library.getLibraryVersion());
//			// Create the Gateway representing the serial GSM modem.
//			SerialModemGateway gateway = new SerialModemGateway("modem.com1", "COM9", 9600, "Huawei", "E3131A");
//			// Set the modem protocol to PDU (alternative is TEXT). PDU is the default, anyway...
//			gateway.setProtocol(Protocols.PDU);
//			// Do we want the Gateway to be used for Inbound messages?
//			gateway.setInbound(true);
//			// Do we want the Gateway to be used for Outbound messages?
//			gateway.setOutbound(true);
//			// Let SMSLib know which is the SIM PIN.
//			gateway.setSimPin("0000");
//			// Set up the notification methods.
//			Service.getInstance().setInboundMessageNotification(inboundNotification);
//			Service.getInstance().setCallNotification(callNotification);
//			Service.getInstance().setGatewayStatusNotification(statusNotification);
//			Service.getInstance().setOrphanedMessageNotification(orphanedMessageNotification);
//			// Add the Gateway to the Service object.
//			Service.getInstance().addGateway(gateway);
//			// Similarly, you may define as many Gateway objects, representing
//			// various GSM modems, add them in the Service object and control all of them.
//			// Start! (i.e. connect to all defined Gateways)
//			Service.getInstance().startService();
//                       
//			// Printout some general information about the modem.
//			System.out.println();
//			System.out.println("Modem Information:");
//			System.out.println("  Manufacturer: " + gateway.getManufacturer());
//			System.out.println("  Model: " + gateway.getModel());
//			System.out.println("  Serial No: " + gateway.getSerialNo());
//			System.out.println("  SIM IMSI: " + gateway.getImsi());
//			System.out.println("  Signal Level: " + gateway.getSignalLevel() + " dBm");
//			System.out.println("  Battery Level: " + gateway.getBatteryLevel() + "%");
//			System.out.println();
//			// In case you work with encrypted messages, its a good time to declare your keys.
//			// Create a new AES Key with a known key value. 
//			// Register it in KeyManager in order to keep it active. SMSLib will then automatically
//			// encrypt / decrypt all messages send to / received from this number.
//			Service.getInstance().getKeyManager().registerKey("+237699092307", new AESKey(new SecretKeySpec("0011223344556677".getBytes(), "AES")));
//			// Read Messages. The reading is done via the Service object and
//			// affects all Gateway objects defined. This can also be more directed to a specific
//			// Gateway - look the JavaDocs for information on the Service method calls.
//			msgList = new ArrayList<InboundMessage>();
//			Service.getInstance().readMessages(msgList, MessageClasses.ALL);
//                         String mess = " dadadad", orgin = " ";
//                         Date date = new Date();
//                           String messagSending = "";
//                         int Hc = 0;
//                       
//			for (InboundMessage msg : msgList){
//			      System.out.println(msg);
//                             
//                               mess = msg.getText();
//                               orgin = "+"+msg.getOriginator();
//                               DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//                            
//                              
//                               String sendDate = dateFormat.format(date);
//                               Hc = msg.hashCode();
//                               GestionEdutiant backup = new GestionEdutiant();
//                               backup.insertRead(orgin, mess, sendDate, Hc);
//                               
//                               
//                               //regularExpression
//                                   Pattern checkRegex  = Pattern.compile("[0-9A-Za-z]{2,7}");
//        
//                                    Matcher regexMatcher = checkRegex.matcher(mess);
//
//                                    String [] zi = new String[20];
//                                    int i = 0;
//                                    while(regexMatcher.find()){
//                                        if(regexMatcher.group().length() != 0){
//                            //                System.out.println(regexMatcher.group().trim());
//                                            zi[i]=regexMatcher.group().trim();
//                                            i++;
//                                        }
//
//
//                                    }
////                                    for (int k = 0; k<i; k++)
////                                    System.out.println("\n" +zi[k]);
//                                    String table = zi[0]+zi[2];
//                                    String matricule = zi[1];
//                               
//                               
//                               // sending process
//                               OutboundMessage sending = new OutboundMessage();
//                                 messagSending = backup.listeStudent(matricule,table);
//                                sending.setRecipient(orgin);
//                                sending.setText(messagSending);
//                               
//                               
//                                Service.getInstance().sendMessage(sending);
//                                
//                                 OutboundMessage.MessageStatuses Status;
//                                 Status = sending.getMessageStatus();
//                           
//                              
//                                String sendDate1 = dateFormat.format(date);
//                                backup.insertSend(orgin,  messagSending, Status+"",sendDate1);
//                               
//                               Service.getInstance().deleteMessage(msg);
//                               
//                        }
//                        
//			// Sleep now. Emulate real world situation and give a chance to the notifications
//			// methods to be called in the event of message or voice call reception.
//			
//                        
//                          
//                      
////                         GestionEdutiant sen = new GestionEdutiant();
////                         OutboundMessage sending = new OutboundMessage(); 
////                         String requete = "select * from read";
////                           
////                        //sending sms to all contants
////                        try{
////                              PreparedStatement ps = (PreparedStatement) DBconnexion.getCon().prepareStatement(requete);
////                              ResultSet result = ps.executeQuery();
////                               while(result.next()){
////
////                                 String originator = result.getString("originator");
////                                 String content = result.getString("content");
////                                  messagSending = sen.listeStudent(content);
////                                sending.setRecipient(originator);
////                                sending.setText(messagSending);
////                               
////                                Service.getInstance().sendMessage(sending);
////                             }
////
////                          }catch(Exception e){
////                              System.out.println(e);
////                          }
//                        
//                        // sending to a single from db
//                        
//			System.in.read();
//                      
//                            
//                      
//		}
//		catch (Exception e)
//		{
//			e.printStackTrace();
//		}
//		finally
//		{
//			Service.getInstance().stopService();
//		}
//	}
//
//	public class InboundNotification implements IInboundMessageNotification
//	{
//		public void process(AGateway gateway, MessageTypes msgType, InboundMessage msg)
//		{
//                    try {
//                        String mess = " ", orgin = " ";
//                        Date date = new Date();
//                        String messagSending = "";
//                        int Hc = 0;
//                        if (msgType == MessageTypes.INBOUND) System.out.println(">>> New Inbound message detected from Gateway: " + gateway.getGatewayId());
//                        else if (msgType == MessageTypes.STATUSREPORT) System.out.println(">>> New Inbound Status Report message detected from Gateway: " + gateway.getGatewayId());
//                        System.out.println(msg);
//                        mess = msg.getText();
//                        orgin = "+"+msg.getOriginator();
//                        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//                               String sendDate = dateFormat.format(date);
//                               Hc = msg.hashCode();
//                               GestionEdutiant backup = new GestionEdutiant();
//                               backup.insertRead(orgin, mess, sendDate, Hc);
//                               
//                                
//                               //regularExpression
//                                   Pattern checkRegex  = Pattern.compile("[0-9A-Za-z]{2,7}");
//        
//                                    Matcher regexMatcher = checkRegex.matcher(mess);
//
//                                    String [] zi = new String[20];
//                                    int i = 0;
//                                    while(regexMatcher.find()){
//                                        if(regexMatcher.group().length() != 0){
//                            //                System.out.println(regexMatcher.group().trim());
//                                            zi[i]=regexMatcher.group().trim();
//                                            i++;
//                                        }
//
//
//                                    }
////                                    for (int k = 0; k<i; k++)
////                                    System.out.println("\n" +zi[k]);
//                                    String table = zi[0]+zi[2];
//                                    String matricule = zi[1];
//                               
//                               
//                               // sending process
//                                OutboundMessage sending = new OutboundMessage();
//                                 messagSending = backup.listeStudent(matricule,table);
//
//                                sending.setRecipient(orgin);
//                                sending.setText(messagSending);
//                                OutboundMessage.MessageStatuses Status;
//                                Status = sending.getMessageStatus();
//                               String sendDate1 = dateFormat.format(date);
//                                        backup.insertSend(orgin,  messagSending, Status+"",sendDate1);
//                                
//                              
//                        try {
//                            Service.getInstance().sendMessage(sending);
//                        } catch (TimeoutException ex) {
//                            Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
//                        } catch (GatewayException ex) {
//                            Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
//                        } catch (IOException ex) {
//                            Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
//                        } catch (InterruptedException ex) {
//                            Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
//                        }
//                        Service.getInstance().deleteMessage(msg);
//                    } catch (SQLException ex) {
//                        Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
//                    } catch (TimeoutException ex) {
//                        Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
//                    } catch (GatewayException ex) {
//                        Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
//                    } catch (IOException ex) {
//                        Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
//                    } catch (InterruptedException ex) {
//                        Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
//                    }
//                   
//		}
//	}
//
//	public class CallNotification implements ICallNotification
//	{
//		public void process(AGateway gateway, String callerId)
//		{
//			System.out.println(">>> New call detected from Gateway: " + gateway.getGatewayId() + " : " + callerId);
//		}
//	}
//
//	public class GatewayStatusNotification implements IGatewayStatusNotification
//	{
//		public void process(AGateway gateway, GatewayStatuses oldStatus, GatewayStatuses newStatus)
//		{
//			System.out.println(">>> Gateway Status change for " + gateway.getGatewayId() + ", OLD: " + oldStatus + " -> NEW: " + newStatus);
//		}
//	}
//
//	public class OrphanedMessageNotification implements IOrphanedMessageNotification
//	{
//		public boolean process(AGateway gateway, InboundMessage msg)
//		{
//			System.out.println(">>> Orphaned message part detected from " + gateway.getGatewayId());
//			System.out.println(msg);
//			// Since we are just testing, return FALSE and keep the orphaned message part.
//			return false;
//		}
//	}
//
////	public static void main(String args[])
////	{
////		ReadMessages app = new ReadMessages();
////		try
////		{
////			app.doIt();
////		}
////		catch (Exception e)
////		{
////			e.printStackTrace();
////		}
////	}
//}
 // ReadMessages.java - Sample application.
//
// This application shows you the basic procedure needed for reading
// SMS messages from your GSM modem, in synchronous mode.
//
// Operation description:
// The application setup the necessary objects and connects to the phone.
// As a first step, it reads all messages found in the phone.
// Then, it goes to sleep, allowing the asynchronous callback handlers to
// be called. Furthermore, for callback demonstration purposes, it responds
// to each received message with a "Got It!" reply.
//
// Tasks:
// 1) Setup Service object.
// 2) Setup one or more Gateway objects.
// 3) Attach Gateway objects to Service object.
// 4) Setup callback notifications.
// 5) Run

package Gui;

import Connexion.DBconnexion;
import Gestion.GestionEdutiant;
import Gui.SmsInterface;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.crypto.spec.SecretKeySpec;
import org.smslib.AGateway;
import org.smslib.AGateway.GatewayStatuses;
import org.smslib.AGateway.Protocols;
import org.smslib.ICallNotification;
import org.smslib.IGatewayStatusNotification;
import org.smslib.IInboundMessageNotification;
import org.smslib.IOrphanedMessageNotification;
import org.smslib.InboundMessage;
import org.smslib.InboundMessage.MessageClasses;
import org.smslib.Library;
import org.smslib.Message.MessageTypes;
import org.smslib.Service;
import org.smslib.crypto.AESKey;
import org.smslib.modem.SerialModemGateway;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextArea;
import org.smslib.GatewayException;
import org.smslib.OutboundMessage;
import org.smslib.TimeoutException;
import java.util.regex.*;
import org.smslib.SMSLibException;

public class ReadMessages extends Thread
{
   


     
        @Override
	public void run()
	{
		// Define a list which will hold the read messages.
		List<InboundMessage> msgList;
		// Create the notification callback method for inbound & status report
		// messages.
		InboundNotification inboundNotification = new InboundNotification();
		// Create the notification callback method for inbound voice calls.
		CallNotification callNotification = new CallNotification();
		//Create the notification callback method for gateway statuses.
		GatewayStatusNotification statusNotification = new GatewayStatusNotification();
		OrphanedMessageNotification orphanedMessageNotification = new OrphanedMessageNotification();
        
        
                
                Scanner read = new Scanner(System.in);
                 Scanner input = new Scanner(System.in);
                
		try
		{
                    SmsInterface.ShowSMS.append("bNotified");
			System.out.println("Example: Read messages from a serial gsm modem.");
			System.out.println(Library.getLibraryDescription());
			System.out.println("Version: " + Library.getLibraryVersion());
			
                        	Service.getInstance().setInboundMessageNotification(inboundNotification);
			Service.getInstance().setCallNotification(callNotification);
			Service.getInstance().setGatewayStatusNotification(statusNotification);
			Service.getInstance().setOrphanedMessageNotification(orphanedMessageNotification);
                        
			msgList = new ArrayList<InboundMessage>();
			Service.getInstance().readMessages(msgList, MessageClasses.ALL);
                         String mess = " dadadad", orgin = " ";
                         Date date = new Date();
                           String messagSending = "";
                         int Hc = 0;
                       
			for (InboundMessage msg : msgList){
			      System.out.println(msg);
                             
                               mess = msg.getText();
                               orgin = "+"+msg.getOriginator();
                               DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                               
                               SmsInterface.ShowSMS.append("\nNumber :" + orgin);
                               SmsInterface.ShowSMS.append("\nContent :" + mess);
                              
                               String sendDate = dateFormat.format(date);
                               Hc = msg.hashCode();
                               GestionEdutiant backup = new GestionEdutiant();
                               backup.insertRead(orgin, mess, sendDate, Hc);
                               
                               
                               //regularExpression
                                   Pattern checkRegex  = Pattern.compile("[0-9A-Za-z]{2,7}");
        
                                    Matcher regexMatcher = checkRegex.matcher(mess);

                                    String [] zi = new String[20];
                                    int i = 0;
                                    while(regexMatcher.find()){
                                        if(regexMatcher.group().length() != 0){
                            //                System.out.println(regexMatcher.group().trim());
                                            zi[i]=regexMatcher.group().trim();
                                            i++;
                                        }


                                    }
//                                    for (int k = 0; k<i; k++)
//                                    System.out.println("\n" +zi[k]);
                                    String table = zi[0]+zi[2];
                                    String matricule = zi[1];
                                    
                                    //Insert Student
//                                    backup.insertStudent(orgin, matricule, zi[0]);
                               
                               
                               // sending process
                               OutboundMessage sending = new OutboundMessage();
                                 messagSending = backup.listeStudent(matricule,table);
                                sending.setRecipient(orgin);
                                sending.setText(messagSending);
                               
                               
                                Service.getInstance().sendMessage(sending);
                                
                                 OutboundMessage.MessageStatuses Status;
                                 Status = sending.getMessageStatus();
                           
                              
                                String sendDate1 = dateFormat.format(date);
                                backup.insertSend(orgin,  messagSending, Status+"",sendDate1);
                               
                               Service.getInstance().deleteMessage(msg);
                               
                        }
                        
			// Sleep now. Emulate real world situation and give a chance to the notifications
			// methods to be called in the event of message or voice call reception.
			
                        
                          
                      
//                         GestionEdutiant sen = new GestionEdutiant();
//                         OutboundMessage sending = new OutboundMessage(); 
//                         String requete = "select * from read";
//                           
//                        //sending sms to all contants
//                        try{
//                              PreparedStatement ps = (PreparedStatement) DBconnexion.getCon().prepareStatement(requete);
//                              ResultSet result = ps.executeQuery();
//                               while(result.next()){
//
//                                 String originator = result.getString("originator");
//                                 String content = result.getString("content");
//                                  messagSending = sen.listeStudent(content);
//                                sending.setRecipient(originator);
//                                sending.setText(messagSending);
//                               
//                                Service.getInstance().sendMessage(sending);
//                             }
//
//                          }catch(Exception e){
//                              System.out.println(e);
//                          }
                        
                        // sending to a single from db
                        
			System.in.read();
                      
                            
                      
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
                    try {
                        Service.getInstance().stopService();
                    } catch (SMSLibException ex) {
                        Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {
                        Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
                    }
		}
	}

	public class InboundNotification implements IInboundMessageNotification
	{
		public void process(AGateway gateway, MessageTypes msgType, InboundMessage msg)
		{
                    try {
                        String mess = " ", orgin = " ";
                        Date date = new Date();
                        String messagSending = "";
                        int Hc = 0;
                        
                        SmsInterface.ShowSMS.append("  ");
                        if (msgType == MessageTypes.INBOUND) SmsInterface.ShowSMS.append(">>>\nNew Inbound message detected from Gateway " );
                        else if (msgType == MessageTypes.STATUSREPORT) SmsInterface.ShowSMS.append(">>>\nNew Inbound Status Report message detected from Gateway ");
                        System.out.println(msg);
                        mess = msg.getText();
                        orgin = "+"+msg.getOriginator();
                        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        
                        
                         SmsInterface.ShowSMS.append("\nNumber :" + orgin);
                         SmsInterface.ShowSMS.append("\nContent :" + mess);
                               
                            String sendDate = dateFormat.format(date);
                            Hc = msg.hashCode();
                            GestionEdutiant backup = new GestionEdutiant();
                            backup.insertRead(orgin, mess, sendDate, Hc);
                               
                                
                               //regularExpression
                                   Pattern checkRegex  = Pattern.compile("[0-9A-Za-z]{2,7}");
        
                                    Matcher regexMatcher = checkRegex.matcher(mess);

                                    String [] zi = new String[20];
                                    int i = 0;
                                    while(regexMatcher.find()){
                                        if(regexMatcher.group().length() != 0){
                            //                System.out.println(regexMatcher.group().trim());
                                            zi[i]=regexMatcher.group().trim();
                                            i++;
                                        }


                                    }
//                                    for (int k = 0; k<i; k++)
//                                    System.out.println("\n" +zi[k]);
                                    String table = zi[0]+zi[2];
                                    String matricule = zi[1];
                                    
                                    //Insert Student
//                                    backup.insertStudent(orgin, matricule, zi[0]);
                                            
                               // sending process
                                OutboundMessage sending = new OutboundMessage();
                                 messagSending = backup.listeStudent(matricule,table);

                                sending.setRecipient(orgin);
                                sending.setText(messagSending);
                                OutboundMessage.MessageStatuses Status;
                                Status = sending.getMessageStatus();
                               String sendDate1 = dateFormat.format(date);
                                        backup.insertSend(orgin,  messagSending, Status+"",sendDate1);
                                
                              
                        try {
                            Service.getInstance().sendMessage(sending);
                        } catch (TimeoutException ex) {
                            Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (GatewayException ex) {
                            Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (IOException ex) {
                            Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (InterruptedException ex) {
                            Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        Service.getInstance().deleteMessage(msg);
                    } catch (SQLException ex) {
                        Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (TimeoutException ex) {
                        Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (GatewayException ex) {
                        Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {
                        Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(ReadMessages.class.getName()).log(Level.SEVERE, null, ex);
                    }
                   
		}
	}

	public class CallNotification implements ICallNotification
	{
		public void process(AGateway gateway, String callerId)
		{
			System.out.println(">>> New call detected from Gateway: " + gateway.getGatewayId() + " : " + callerId);
		}
	}

	public class GatewayStatusNotification implements IGatewayStatusNotification
	{
		public void process(AGateway gateway, GatewayStatuses oldStatus, GatewayStatuses newStatus)
		{
			System.out.println(">>> Gateway Status change for " + gateway.getGatewayId() + ", OLD: " + oldStatus + " -> NEW: " + newStatus);
		}
	}

	public class OrphanedMessageNotification implements IOrphanedMessageNotification
	{
		public boolean process(AGateway gateway, InboundMessage msg)
		{
			System.out.println(">>> Orphaned message part detected from " + gateway.getGatewayId());
			System.out.println(msg);
			// Since we are just testing, return FALSE and keep the orphaned message part.
			return false;
		}
	}
        
            
	public static void main(String args[])
	{
		ReadMessages app = new ReadMessages();
		try
		{
			app.run();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}