/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Abstract nists;

/**
 *
 * @author BETHEL
 */
public class Administrator extends Person {
    
    private String password;

    public Administrator() {
    }

    public Administrator(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
    
}
