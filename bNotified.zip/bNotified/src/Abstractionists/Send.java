/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Abstractionists;

/**
 *
 * @author BETHEL
 */
public class Send {
    
    
    private String tel;
    private String content;
    private String date;

    public Send() {
    }

    public Send(String tel, String content, String date) {
        this.tel = tel;
        this.content = content;
        this.date = date;
    }

    public String getTel() {
        return tel;
    }

    public String getContent() {
        return content;
    }

    public String getDate() {
        return date;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setDate(String date) {
        this.date = date;
    }
    
}
