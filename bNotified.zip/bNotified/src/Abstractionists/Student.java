/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Abstractionists; 
/**
 *
 * @author BETHEL
 */
public class Student extends Person {
    
    private String Tel;

    public Student() {
    }

    public Student(String Tel) {
        this.Tel = Tel;
    }

    public String getTel() {
        return Tel;
    }

    public void setTel(String Tel) {
        this.Tel = Tel;
    }
    
    
    
    
}
