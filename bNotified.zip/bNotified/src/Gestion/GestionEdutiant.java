/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gestion;

import Connexion.DBconnexion;
import com.mysql.jdbc.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Date;



/**
 *
 * @author BETHEL
 */
public class GestionEdutiant {

   
    
    
    public void insertRead(String originator, String content, String date, int hashcode) throws SQLException{
//         String requete = "select * from read";
//         boolean test = false;
//          try{
//                PreparedStatement ps = (PreparedStatement) DBconnexion.getCon().prepareStatement(requete);
//               ResultSet result = ps.executeQuery();
//               while(result.next()){
//
//                    if(originator.equals(result.getString("originator")) && content.equals(result.getString("content"))){
//                         test = true;   
//                    }
//               }
//            
//            }catch(Exception e){
//                System.out.println(e);
//            }
//            
//          if(test == false){
            String  request = "insert into resave (originator, content, date, hashcode) " + "values (?, ?, ?, ?)";
            PreparedStatement ps; 
            ps = (PreparedStatement) DBconnexion.getCon().prepareStatement(request);
            
         
            ps.setString(1, originator);
            ps.setString(2, content);
            ps.setString(3,  date);
            ps.setInt(4, hashcode);
            
            ps.executeUpdate();
//          }
    }
    
    
    
     
    public void insertSend(String originator, String content, String Status, String date) throws SQLException{
     
            String  request = "insert into send (originator, content, Status, date) "  + "values (?, ?, ?, ?)";
            PreparedStatement ps; 
            ps = (PreparedStatement) DBconnexion.getCon().prepareStatement(request);
            
            ps.setString(1, originator);
            ps.setString(2, content);
            ps.setString(3, Status);
        
         
             ps.setString(4, date);
            
            ps.executeUpdate();
          
    }
    
     public void insertStudent(String originator, String matricule, String level) throws SQLException{
         
         String requete = "select * from studentsms";
         boolean test = false;
          try{
                PreparedStatement ps = (PreparedStatement) DBconnexion.getCon().prepareStatement(requete);
               ResultSet result = ps.executeQuery();
               while(result.next()){

                    if(originator.equals(result.getString("tel")) && matricule.equals(result.getString("matricule"))){
                         test = true;   
                    }
               }
            
            }catch(Exception e){
                System.out.println(e);
            }
            
          if(test == false){
     
            String  request = "insert into studentsms (tel, matricule, level) "  + "values (?, ?, ?)";
            PreparedStatement ps; 
            ps = (PreparedStatement) DBconnexion.getCon().prepareStatement(request);
            
            ps.setString(1, originator);
            ps.setString(2, matricule);
            ps.setString(3, level);
        
         
            ps.executeUpdate();
          }
          
    }
    
//       public void suprimeEtudiant(String matricule){
//           String requete = "delete from student where matricule = ?";
//           try{
//                PreparedStatement ps = (PreparedStatement) DBconnexion.getCon().prepareStatement(requete);
//                 ps.setString(1, matricule);
//               
//                ps.executeUpdate();
//            
//            }catch(Exception e){
//                System.out.println(e);
//            }
//       
//       }
       
//       public void modiferEtudiant(String matricule, String newMatricule, String newName, int newtelephone) throws SQLException{
//       
//            String requete = "update student set matricule = ?, name = ?, telephone = ? where matricule = ?";
//                   
//                            
//            try{
//                PreparedStatement ps = (PreparedStatement) DBconnexion.getCon().prepareStatement(requete);
//                 ps.setString(1,newMatricule);
//                ps.setString(2, newName);
//                ps.setInt(3, newtelephone);
//                ps.setString(4, matricule);
//                ps.executeUpdate();
//            
//            }catch(Exception e){
//                System.out.println(e);
//            }
//       }
       
      
       
       public String listeStudent(String matr, String table){
           //selecting table in 
         String requete = "select * from " + table;  
//           String requete = "select * from note";       
            String response = " not avaliable";  
            String resp = "Abstractionists";
            int numbcol = 0;
            try{
                PreparedStatement ps = (PreparedStatement) DBconnexion.getCon().prepareStatement(requete);
               ResultSet result = ps.executeQuery();
               ResultSetMetaData se = result.getMetaData();
               numbcol = se.getColumnCount();
               
//               String name0 = se.getColumnName(1);
//                String name1 = se.getColumnName(2);
//                 String name2 = se.getColumnName(3);
//                  String name3 = se.getColumnName(4);
//                  String name4 = se.getColumnName(5);
//                  String name5 = se.getColumnName(5);
              int i = 1;
           
               while(  result.next() ){
//                   
                    if(matr.equalsIgnoreCase(result.getString("matricule"))){
                  
//                     response = name0+ ": "+ result.getString(name0) + "\n" +name1 + ": "+ result.getDouble(name1) +  "\n" +name2 + 
//                             ": "+result.getDouble(name2) + "\n"+name3 + ": "+result.getDouble(name3) +  "\n"+name4 + ": "+result.getDouble(name4);
                        for(int j = 1; j<=numbcol; j++){
                            response = "\n" + se.getColumnName(j)+ ": "+ result.getString(se.getColumnName(j));
                            resp = resp + response;
                        }
                                   
                                    
                    }
                 
                 
                      
               }
            
                           
            }catch(Exception e){
                System.out.println(e);
            }
            
            return resp ;

       }
       
       
        //method listing all outboundsms
       public ResultSet listSMS(){
           //selecting table in 
           String requete = "select * from send";       
                
           ResultSet result = null;
            try{
                PreparedStatement ps = (PreparedStatement) DBconnexion.getCon().prepareStatement(requete);
               result = ps.executeQuery();
               
            
            }catch(Exception e){
                System.out.println(e);
            }
             return result;
       }
       
       //method listing all inboundsms
        public ResultSet listresave(){
           //selecting table in 
           String requete = "select * from resave";       
                
           ResultSet result = null;
            try{
                PreparedStatement ps = (PreparedStatement) DBconnexion.getCon().prepareStatement(requete);
               result = ps.executeQuery();
               
            
            }catch(Exception e){
                System.out.println(e);
            }
             return result;
       }
      
 }

   

